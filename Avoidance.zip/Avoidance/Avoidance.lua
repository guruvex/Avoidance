-- Written By: Kip Potter (a.k.a Mythraun [Fury] - Level 80 Deathnight - Stonemaul)

-- Global version variable...
AVOIDANCE_VERSION = "1.0.1.0.A";

-- Other globals.
Avoidance_Settings = {};

-- Locals.
local frame;

--------------------------------------------------------------------------------
-- Handles loading the add-on.
--------------------------------------------------------------------------------
function Avoidance_OnLoad(Self)
	DEFAULT_CHAT_FRAME:AddMessage(format("Avoidance v%s loaded.", AVOIDANCE_VERSION));
	
	-- Register the game slash commands necessary for our functionality
	SLASH_AVOIDANCE1 = "/avoid";
	SLASH_AVOIDANCE2 = "/avoidance";
	SlashCmdList["AVOIDANCE"] = Avoidance_SlashCommand;
	
	-- Register the events.
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("UNIT_STATS");
	this:RegisterEvent("UNIT_AURA");
	this:RegisterEvent("UNIT_DEFENSE");
end

--------------------------------------------------------------------------------
-- Shows the command (command-line parameters) options for avoidance.
--------------------------------------------------------------------------------
function Avoidance_ShowCommands()
	print("Avoidance command options:");
	if (frame:IsShown()) then
		print("  show [true] - Shows the avoidance window.");
		print("  hide [false] - Hides the avoidance window.");
	else
		print("  show [false] - Shows the avoidance window.");
		print("  hide [true] - Hides the avoidance window.");
	end
	
	if (Avoidance_Settings.EnableDebugging) then
		print("  debugon  [true] - Enables displaying debug information to the chat window.");
		print("  debugoff [false] - Disables displaying debug information to the chat window.");
	else
		print("  debugon  [false] - Enables displaying debug information to the chat window.");
		print("  debugoff [true] - Disables displaying debug information to the chat window.");
	end
	print("  ver - Shows the installed version of Avoidance.");
	print("  resetframe - Resets the Avoidance frame to it's default position.");
end

--------------------------------------------------------------------------------
-- Handles the slash commands '/avoid' and '/avoidance'.
--------------------------------------------------------------------------------
function Avoidance_SlashCommand(msg)
	if (msg == "ver") then
		print(format("Avoidance Version: %s", AVOIDANCE_VERSION));
	elseif (msg == "show") then
		if (not frame:IsShown()) then
			frame:Show();
		end
	elseif (msg == "hide") then
		if (frame:IsShown()) then
			frame:Hide();
		end
	elseif (msg == "debugon") then
		Avoidance_Settings.EnableDebugging = true;
	elseif (msg == "debugoff") then
		Avoidance_Settings.EnableDebugging = false;
	elseif (msg == "resetframe") then
		frame:ClearAllPoints();
		frame:SetPoint("CENTER", WorldFrame, 0, 0);
		frame:Show();
	else
		Avoidance_ShowCommands();
	end
end

--------------------------------------------------------------------------------
-- Shows the avoidance breakdown.
--------------------------------------------------------------------------------
function Avoidance_ShowAvoidance(msg)
	local baseDefense,armorDefense=UnitDefense("player");
	local defenseContrib = (baseDefense + armorDefense - UnitLevel("player") * 5) / 25;
	
	-- Calculate total avoidance.
	local baseAvoidance = 5;
	local bossMissChance = 5 + defenseContrib;
	local dodge = GetDodgeChance();
	-- local block = GetBlockChance(); Block chance no longer part of avoidance...it's mitigation.
	local parry = GetParryChance();
	local totalAvoidance = baseAvoidance + defenseContrib + dodge + parry + bossMissChance;
	
	-- TODO: Check for shield, and if present, add block chance, otherwise don't add block chance.
	-- TODO: Should we check for a weapon for parry chance?
	-- TODO: Remove block from /avoid and add /mitigation
	
	if (msg == "min") then
		print(format("Total avoidance: %.2f%%", totalAvoidance));
	else
		if (Avoidance_Settings.EnableDebugging) then
			print("Total Avoidance Breakdown");
			print(format("  Boss Miss Chance : %.2f%%", bossMissChance));
			print(format("  Base avoidance : %.2f%%", baseAvoidance));
			print(format("  Def. avoidance : %.2f%%", defenseContrib));
			print(format("  Dodge : %.2f%%", dodge));
			print(format("  Parry : %.2f%%", parry));
			print(format("Total Avoidance : %.2f%%", totalAvoidance));
		end
		
		AvoidanceBossText:SetText(format("%002.2f%% - Boss Miss Chance", bossMissChance));
		AvoidanceBaseText:SetText(format("%002.2f%% - base avoidance", baseAvoidance));
		AvoidanceDefText:SetText(format("%002.2f%% - avoid. from defense", defenseContrib));
		AvoidanceDodgeText:SetText(format("%002.2f%% - dodge", dodge));
		AvoidanceParryText:SetText(format("%002.2f%% - parry", parry));
		AvoidanceTotalText:SetText(format("%002.2f%% - TOTAL AVOIDANCE", totalAvoidance));
	end
end

--------------------------------------------------------------------------------
-- Creates the Avoidance frame.
--------------------------------------------------------------------------------
function Avoidance_CreateFrame()
	if (frame == nil) then
		frame = CreateFrame("Button", "AvoidanceFrame", UIParent);
	end
	
	if (Avoidance_Settings.Pos == nil) then
		frame:SetPoint("CENTER", 0, 200);
	else
		frame:SetPoint(Avoidance_Settings.Pos, Avoidance_Settings.PosX, Avoidance_Settings.PosY);
	end
	
	frame:SetHeight(100);
	frame:SetBackdrop(
		{
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
			edgeSize = 16,
			insets = { left = 5, right = 5, top = 5, bottom = 5 },
			tile = true,
			tileSize = 16
		}
	);
	frame:SetBackdropColor(0.09, 0.09, 0.19, 0.5);
	frame:SetBackdropBorderColor(0.5, 0.5, 0.5, 1);
	
	-- Title top.
	local y = -6;
	
	AvoidanceTitle = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceTitle:SetPoint("TOPLEFT", 10, y);
	AvoidanceTitle:SetText("Total avoidance breakdown");
	
	y = y - 13;
	AvoidanceBossText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceBossText:SetPoint("TOPLEFT", 10, y);
	AvoidanceBossText:SetText("00.00% - base boss miss chance");
	
	y = y - 13;
	AvoidanceBaseText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceBaseText:SetPoint("TOPLEFT", 10, y);
	AvoidanceBaseText:SetText("00.00% - base avoidance");
	
	y = y - 13;
	AvoidanceDefText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceDefText:SetPoint("TOPLEFT", 10, y);
	AvoidanceDefText:SetText("00.00% - avoid. from defense");
	
	y = y - 13;
	AvoidanceDodgeText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceDodgeText:SetPoint("TOPLEFT", 10, y);
	AvoidanceDodgeText:SetText("00.00% - dodge");
	
	y = y - 13;
	AvoidanceParryText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceParryText:SetPoint("TOPLEFT", 10, y);
	AvoidanceParryText:SetText("00.00% - parry");
	
	y = y - 13;
	AvoidanceDashesText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceDashesText:SetPoint("TOPLEFT", 10, y);
	AvoidanceDashesText:SetText("-------------------------");
	
	y = y - 13;
	AvoidanceTotalText = frame:CreateFontString(nil, nil, "GameFontNormalSmall");
	AvoidanceTotalText:SetPoint("TOPLEFT", 10, y);
	AvoidanceTotalText:SetText("00.00% - TOTAL AVOIDANCE");
	
	y = y - 19;
	frame:SetHeight(y * -1);
	
	frame:SetWidth(175);
--	frame:SetScript("OnClick", function(This) Avoidance_Reset(); end);
	frame:SetMovable(true);
	frame:RegisterForDrag("LeftButton");

--  this fixed by hobbit for turtle wow.
	frame:SetScript("OnDragStart", function() frame:StartMoving(); end);
	frame:SetScript("OnDragStop", function()
		frame:StopMovingOrSizing()
		Avoidance_Settings.Pos, Avoidance_Settings.PosX, Avoidance_Settings.PosY = "BOTTOMLEFT",
		frame:GetLeft(), frame:GetBottom()
		end
	);
	Avoidance_ShowAvoidance(nil);
end

--------------------------------------------------------------------------------
-- Resets avoidance.
--------------------------------------------------------------------------------
function Avoidance_Reset()
	Avoidance_ShowAvoidance(nil);
end

--------------------------------------------------------------------------------
-- Fires when an event we are listening to is fired.
--------------------------------------------------------------------------------
function Avoidance_OnEvent()
	if (event == "VARIABLES_LOADED") then
		Avoidance_CreateFrame();
	elseif (event == "UNIT_STATS") then
		Avoidance_ShowAvoidance("stats");
	elseif (event == "UNITDEFENSE") then
		Avoidance_ShowAvoidance("defense");
	elseif (event == "UNIT_AURA") then
		Avoidance_ShowAvoidance("aura");
	end
	
	if (Avoidance_Show == 0) then
		frame:Show();
		Avoidance_Show = 1;
	end
end

