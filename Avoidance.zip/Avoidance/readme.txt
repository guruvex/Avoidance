Title: Avoidance
Notes: Adds the ability to view total avoidance and avoidance breakdown
Author: Kip Potter (a.k.a. Level 80 Deathknight "Mythraun")
Version: 1.0.1.1.B

commands
/avoid show
/avoid hide

Revised by GuruBlade and Hobbit for turtle WoW 1/2023

---Change log--- 
added boss miss chance to the table.
fixed the frame movement crash for the 1.12 client.
fixed dialog for commands to post in chat correctly.
changed default behaviour on log in, to hide window instead of always show. 



